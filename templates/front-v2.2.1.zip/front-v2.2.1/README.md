# First of all, we thank you for your purchase and willingness of using Front in your projects! #

With an incredibly beautiful, fully responsive, and mobile-first projects on the web – Front Multipurpose Responsive Template is the perfect starting point for any creative and professional sites. Get started with Front’s components and options for laying out your Front project, including SVG components, powerful scripts, fully detailed documentation, and yet developer friendly code.


### How to start with Front? ###

It's simple and easy, just open `documentation/index.html` and Front's documentation will guide you with detailed step by step information.


### Where to download the Sketch version of Front? ###

In order to download full sketch version, please open the below link and use the provided password:

Download Link: http://bit.ly/front-template-skecht
Password: 9tpfrontW[jXpskecht(8

The reason why we include Sketch file separately is to reduce the original download package size after purchase.


### License ###

Front is licensed under Bootstrap Themes and you can find more detailed information about it here: https://themes.getbootstrap.com/licenses


### Free updates and support ###

We would like to draw your attention to the fact that after purchasing a Front Template copy, you get the right for a lifetime entitlement to download updates for FREE! Need help? For any questions or concerns, reach us out at support@htmlstream.com


### Need Front Template customization? ###

We offer affordable, professional and trendy customized design solutions, solely for your own projects! Front Template can be easily customized with its cutting-edge components and features. However, if you feel you need any further customization please drop us a message at clients@htmlstream.com and our dedicated team will assist you with your inquiries.